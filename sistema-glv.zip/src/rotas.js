import React from 'react';
import ListagemMarcas from "./views/listagemMarcas"
import { Route, Routes, BrowserRouter } from 'react-router-dom';

function Rotas(props) {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path='/listagemMarcas/:idParam?'
          element={<ListagemMarcas />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default Rotas;